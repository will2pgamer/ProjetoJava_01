package Classes_Cad;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Consulta_Sala_cafe extends JFrame {

	private JPanel contentPane;
	private JTable consultasala;
	private JTable consultacafe;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Consulta_Sala_cafe frame = new Consulta_Sala_cafe();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Consulta_Sala_cafe() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 28, 193, 87);
		contentPane.add(scrollPane);
		
		consultasala = new JTable();
		consultasala.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
			},
			new String[] {
				"ID", "Sala", "Lota\u00E7\u00E3o"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, true, true
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane.setColumnHeaderView(consultasala);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(231, 28, 193, 87);
		contentPane.add(scrollPane_1);
		
		consultacafe = new JTable();
		consultacafe.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
			},
			new String[] {
				"ID", "Espa\u00E7o Caf\u00E9", "Lota\u00E7\u00E3o"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, true, true
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane_1.setColumnHeaderView(consultacafe);
		
		JLabel lblID1 = new JLabel("ID");
		lblID1.setBounds(10, 11, 46, 14);
		contentPane.add(lblID1);
		
		JLabel lblSala = new JLabel("Sala");
		lblSala.setBounds(77, 11, 46, 14);
		contentPane.add(lblSala);
		
		JLabel lblLotacao1 = new JLabel("Lota\u00E7\u00E3o");
		lblLotacao1.setBounds(144, 11, 46, 14);
		contentPane.add(lblLotacao1);
		
		JLabel lblID2 = new JLabel("ID");
		lblID2.setBounds(231, 11, 46, 14);
		contentPane.add(lblID2);
		
		JLabel lblEspacoCafe = new JLabel("Caf\u00E9");
		lblEspacoCafe.setBounds(297, 11, 57, 14);
		contentPane.add(lblEspacoCafe);
		
		JLabel lblLotacao2 = new JLabel("Lota\u00E7\u00E3o");
		lblLotacao2.setBounds(364, 11, 46, 14);
		contentPane.add(lblLotacao2);
		
		JButton btnConsultar = new JButton("Consultar");
		btnConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				try {
					Connection con = Conexao.faz_conexao();
					
					String sql = "select *from sala_lotacao";
					
					String sql2 = "select *from cafe_lotacao";
					
					
					PreparedStatement st = con.prepareStatement(sql);
					
					PreparedStatement st2 = con.prepareStatement(sql2);
					
					ResultSet rs = st.executeQuery();
					
					ResultSet rs2 = st2.executeQuery();
					
					DefaultTableModel model = (DefaultTableModel) consultasala.getModel();
					
					DefaultTableModel model2 = (DefaultTableModel) consultacafe.getModel();
					
					model.setNumRows(0);
					
					model2.setNumRows(0);
					
					while (rs.next() && rs2.next()) {
						
					model.addRow(new Object[] {rs.getString("id"), rs.getString("sala"), rs.getString("lotacao")});
					
					model2.addRow(new Object[] {rs2.getString("id"), rs2.getString("espacocafe"), rs2.getString("lotacao")});
					
					}
					
					st.close();
					st2.close();
					rs.close();
					rs2.close();
					con.close();
					
					JOptionPane.showMessageDialog(null, "Busca Concluida!");
					
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
			}
				
				
			
		});
		btnConsultar.setBounds(61, 191, 129, 23);
		contentPane.add(btnConsultar);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
			}
		});
		btnCancelar.setBounds(272, 191, 107, 23);
		contentPane.add(btnCancelar);
	}

}
