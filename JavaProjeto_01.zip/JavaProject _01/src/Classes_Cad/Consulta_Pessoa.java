package Classes_Cad;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Component;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Consulta_Pessoa extends JFrame {

	private JPanel contentPane;
	private JTable Consulta_Pessoa_table;
	private JTextField tfBusca;
	private JTextField tfNome;
	private JTextField tfSobrenome;
	private JLabel lblID;
	private JButton btnListaNomes;
	private JLabel lblID2;
	private JLabel lblNome2;
	private JLabel lblSobrenome2;
	private JButton btnApagar;
	private JButton btnAtualizar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Consulta_Pessoa frame = new Consulta_Pessoa();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Consulta_Pessoa() {
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(31, 42, 367, 70);
		contentPane.add(scrollPane);
		
		Consulta_Pessoa_table = new JTable();
		Consulta_Pessoa_table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
			},
			new String[] {
				"ID", "Nome", "Sobrenome"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane.setColumnHeaderView(Consulta_Pessoa_table);
		
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(tfBusca.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Informe o ID!");
				} else {
				try {
					Connection con = Conexao.faz_conexao();
					
					String sql = "select *from dado_pessoa where id like ?";
					
					PreparedStatement st = con.prepareStatement(sql);
					
					st.setString(1, "%"+tfBusca.getText());
					
					ResultSet rs = st.executeQuery();
					
					while (rs.next()) {
						
						tfNome.setText(rs.getString("Nome"));
						
						tfSobrenome.setText(rs.getString("Sobrenome"));
						
					}
					
					rs.close();
					con.close();
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			
				
				
			}
			}
		});
		btnBuscar.setBounds(31, 228, 114, 23);
		contentPane.add(btnBuscar);
		
		tfBusca = new JTextField();
		tfBusca.setBounds(31, 197, 114, 20);
		contentPane.add(tfBusca);
		tfBusca.setColumns(10);
		
		tfNome = new JTextField();
		tfNome.setEditable(false);
		tfNome.setBounds(73, 142, 102, 20);
		contentPane.add(tfNome);
		tfNome.setColumns(10);
		
		tfSobrenome = new JTextField();
		tfSobrenome.setEditable(false);
		tfSobrenome.setBounds(261, 142, 137, 20);
		contentPane.add(tfSobrenome);
		tfSobrenome.setColumns(10);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setBounds(33, 145, 46, 14);
		contentPane.add(lblNome);
		
		JLabel lblSobrenome = new JLabel("Sobrenome:");
		lblSobrenome.setBounds(185, 145, 89, 14);
		contentPane.add(lblSobrenome);
		
		lblID = new JLabel("ID:");
		lblID.setBounds(31, 183, 46, 14);
		contentPane.add(lblID);
		
		btnListaNomes = new JButton("Listar Nomes");
		btnListaNomes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					Connection con = Conexao.faz_conexao();
					
					String sql = "select *from dado_pessoa";
					
					PreparedStatement st = con.prepareStatement(sql);
					
					ResultSet rs = st.executeQuery();
					
					DefaultTableModel model = (DefaultTableModel) Consulta_Pessoa_table.getModel();
					
					model.setNumRows(0);
					
					while (rs.next()) {
						
					model.addRow(new Object[] {rs.getString("id"), rs.getString("nome"), rs.getString("sobrenome")});
					
					}
					
					rs.close();
					con.close();

					
					
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
			}
		});
		btnListaNomes.setBounds(284, 173, 124, 28);
		contentPane.add(btnListaNomes);
		
		lblID2 = new JLabel("ID");
		lblID2.setBounds(31, 11, 124, 23);
		contentPane.add(lblID2);
		
		lblNome2 = new JLabel("Nome");
		lblNome2.setBounds(153, 11, 121, 18);
		contentPane.add(lblNome2);
		
		lblSobrenome2 = new JLabel("Sobrenome");
		lblSobrenome2.setBounds(284, 11, 93, 18);
		contentPane.add(lblSobrenome2);
		
		btnApagar = new JButton("Apagar ID");
		btnApagar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(tfBusca.getText().equals("")) {
					
					JOptionPane.showMessageDialog(null, "informe ID!");
				} else {
				try {
					
					Connection con = Conexao.faz_conexao();
					
					String sql="delete from dado_pessoa where id=?";
					
					PreparedStatement st = con.prepareStatement(sql);
					
					st.setString(1, tfBusca.getText());
					
					st.execute();
					
					st.close();
					con.close();
					
					JOptionPane.showMessageDialog(null, "Excluido!");
					
					
					
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				

				
				
				
			}
			}
		});
		btnApagar.setBounds(166, 193, 108, 41);
		contentPane.add(btnApagar);
		
		btnAtualizar = new JButton("Atualizar ID");
		btnAtualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				

				Atualizar_CADPESSOA exibir = new Atualizar_CADPESSOA();
				exibir.setVisible(true);
				
				
				
			}
		});
		btnAtualizar.setBounds(284, 223, 124, 28);
		contentPane.add(btnAtualizar);
	}
}
