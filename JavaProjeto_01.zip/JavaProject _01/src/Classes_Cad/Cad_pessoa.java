package Classes_Cad;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;

public class Cad_pessoa extends JFrame {

	private JPanel contentPane;
	private JTextField tfNome;
	private JTextField tfSobrenome;
	private JTextField tfNome2;
	private JTextField tfLotacao;
	private JTextField tfEspacoCafe;
	private JTextField tfLotacao_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cad_pessoa frame = new Cad_pessoa();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Cad_pessoa() {
		setTitle("Tela Principal");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 511, 345);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnCadastro_Pessoa = new JButton("Cadastro Pessoa");
		btnCadastro_Pessoa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(tfNome.getText().equals("") || tfSobrenome.getText().equals("")){
					JOptionPane.showInternalMessageDialog(null, "Nome/Sobrenome em Branco!");
				} else {
				
				try {
					
					Connection con = Conexao.faz_conexao();
					
					String sql = "insert into dado_pessoa(Nome, Sobrenome) values (?, ?)";
					
					PreparedStatement st = con.prepareStatement(sql);
					
					st.setString(1,tfNome.getText());
					st.setString(2, tfSobrenome.getText());
					
					st.execute();
					st.close();
					con.close();
					
					JOptionPane.showMessageDialog(null, "Cadastrado com Sucesso!");
					
					tfNome.setText("");
					tfSobrenome.setText("");
					
				} 
				
				catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
			}
		}
		});
		btnCadastro_Pessoa.setBounds(20, 11, 188, 23);
		contentPane.add(btnCadastro_Pessoa);
		
		JButton btnCadastro_Sala_Eventos = new JButton("Cadastro Sala Eventos");
		btnCadastro_Sala_Eventos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(tfNome2.getText().equals("") || tfLotacao.getText().equals("")){
					
					JOptionPane.showInternalMessageDialog(null, "Nome/Lota��o em Branco!");
					
				} else {
				
					try {
					
					Connection con = Conexao.faz_conexao();
					
					String sql = "insert into sala_lotacao(sala, lotacao) values (?, ?)";
					
					PreparedStatement st = con.prepareStatement(sql);
					
					st.setString(1, tfNome2.getText());
					
					st.setString(2, tfLotacao.getText());
					
					st.execute();
					st.close();
					con.close();
					
					JOptionPane.showMessageDialog(null, "Cadastrado com Sucesso!");
					
					tfNome2.setText("");
					tfLotacao.setText("");
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			
				
				
			}
		}
		});
		btnCadastro_Sala_Eventos.setBounds(285, 11, 188, 23);
		contentPane.add(btnCadastro_Sala_Eventos);
		
		JButton btnCadastro_Espaco_cafe = new JButton("Cadastro Espa\u00E7o Caf\u00E9");
		btnCadastro_Espaco_cafe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(tfEspacoCafe.getText().equals("") || tfLotacao_1.getText().equals("")){
					
					JOptionPane.showInternalMessageDialog(null, "SalaCafe/Lota��o em Branco!");
					
				} else {
				
				
				try {
					
					
					Connection con =  Conexao.faz_conexao();
					
					String sql = "insert into cafe_lotacao(espacocafe, lotacao) values (?,?)";
					
					PreparedStatement st = con.prepareStatement(sql);
					
					st.setString(1, tfEspacoCafe.getText());
					st.setString(2, tfLotacao_1.getText());
					
					st.execute();
					st.close();
					con.close();
					

					JOptionPane.showMessageDialog(null, "Cadastrado com Sucesso!");
					
					tfEspacoCafe.setText("");
					tfLotacao_1.setText("");
					
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				
			}
			}
		});
		btnCadastro_Espaco_cafe.setBounds(118, 129, 230, 23);
		contentPane.add(btnCadastro_Espaco_cafe);
		
		JButton btnConsulta_pessoa = new JButton("Consulta Pessoa");
		btnConsulta_pessoa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				Consulta_Pessoa exibir = new Consulta_Pessoa();
				exibir.setVisible(true);
				
				
				
			}
		});
		btnConsulta_pessoa.setBounds(111, 233, 246, 23);
		contentPane.add(btnConsulta_pessoa);
		
		JButton btnConsulta_Sala_Espaco = new JButton("Consulta Sala e Espa\u00E7o");
		btnConsulta_Sala_Espaco.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Consulta_Sala_cafe exibir = new Consulta_Sala_cafe();
				exibir.setVisible(true);
				
			}
		});
		btnConsulta_Sala_Espaco.setBounds(111, 267, 244, 23);
		contentPane.add(btnConsulta_Sala_Espaco);
		
		tfNome = new JTextField();
		tfNome.setBounds(89, 55, 119, 20);
		contentPane.add(tfNome);
		tfNome.setColumns(10);
		
		tfSobrenome = new JTextField();
		tfSobrenome.setBounds(89, 98, 119, 20);
		contentPane.add(tfSobrenome);
		tfSobrenome.setColumns(10);
		
		tfNome2 = new JTextField();
		tfNome2.setBounds(354, 55, 119, 20);
		contentPane.add(tfNome2);
		tfNome2.setColumns(10);
		
		tfLotacao = new JTextField();
		tfLotacao.setBounds(354, 98, 119, 20);
		contentPane.add(tfLotacao);
		tfLotacao.setColumns(10);
		
		tfEspacoCafe = new JTextField();
		tfEspacoCafe.setBounds(218, 163, 130, 20);
		contentPane.add(tfEspacoCafe);
		tfEspacoCafe.setColumns(10);
		
		tfLotacao_1 = new JTextField();
		tfLotacao_1.setBounds(218, 191, 130, 20);
		contentPane.add(tfLotacao_1);
		tfLotacao_1.setColumns(10);
		
		JLabel lbNome = new JLabel("Nome:");
		lbNome.setBounds(10, 58, 46, 14);
		contentPane.add(lbNome);
		
		JLabel lblSobrenome = new JLabel("Sobrenome:");
		lblSobrenome.setBounds(10, 101, 76, 14);
		contentPane.add(lblSobrenome);
		
		JLabel lbNome2 = new JLabel("Nome:");
		lbNome2.setBounds(285, 58, 63, 14);
		contentPane.add(lbNome2);
		
		JLabel lbLotacao = new JLabel("Lota\u00E7\u00E3o:");
		lbLotacao.setBounds(285, 101, 63, 14);
		contentPane.add(lbLotacao);
		
		JLabel lbEspacoCafe = new JLabel("Espa\u00E7o Caf\u00E9:");
		lbEspacoCafe.setBounds(118, 166, 90, 14);
		contentPane.add(lbEspacoCafe);
		
		JLabel lbLotacao2 = new JLabel("Lota\u00E7\u00E3o:");
		lbLotacao2.setBounds(118, 194, 90, 14);
		contentPane.add(lbLotacao2);
	}
}
