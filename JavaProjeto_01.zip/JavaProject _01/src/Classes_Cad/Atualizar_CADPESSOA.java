package Classes_Cad;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.mysql.cj.x.protobuf.MysqlxPrepare.Execute;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class Atualizar_CADPESSOA extends JFrame {

	private JPanel contentPane;
	private JTextField tfNome;
	private JTextField tfSobrenome;
	private JTextField tfID;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Atualizar_CADPESSOA frame = new Atualizar_CADPESSOA();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Atualizar_CADPESSOA() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setTitle("Atualizar Cadastro");
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnAtualizar = new JButton("Atualizar");
		btnAtualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(tfID.getText().equals("") || tfNome.getText().equals("")) {
					
					JOptionPane.showMessageDialog(null, "Busque o ID!");
					
				}else {
				
					
				try {
					
					Connection con = Conexao.faz_conexao();
					
					String sql =  "update dado_pessoa set nome=?, sobrenome=? where id=?";
					
					PreparedStatement st = con.prepareStatement(sql);
					
					st.setString(1, tfNome.getText());
					st.setString(2, tfSobrenome.getText());
					st.setString(3, tfID.getText());
					
					st.execute();
					st.close();
					con.close();
					
					JOptionPane.showMessageDialog(null, "Atualizado com Sucesso!");
					
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
			}
		});
		btnAtualizar.setBounds(30, 210, 168, 23);
		contentPane.add(btnAtualizar);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		
			dispose();
				
			}
		});
		btnCancelar.setBounds(234, 210, 168, 23);
		contentPane.add(btnCancelar);
		
		tfNome = new JTextField();
		tfNome.setBounds(140, 87, 168, 20);
		contentPane.add(tfNome);
		tfNome.setColumns(10);
		
		tfSobrenome = new JTextField();
		tfSobrenome.setBounds(140, 118, 168, 23);
		contentPane.add(tfSobrenome);
		tfSobrenome.setColumns(10);
		
		tfID = new JTextField();
		tfID.setBounds(140, 56, 86, 20);
		contentPane.add(tfID);
		tfID.setColumns(10);
		
		JLabel lbID = new JLabel("ID:");
		lbID.setBounds(30, 59, 86, 14);
		contentPane.add(lbID);
		
		JLabel lbNome = new JLabel("Nome:");
		lbNome.setBounds(30, 90, 86, 14);
		contentPane.add(lbNome);
		
		JLabel lbSobrenome = new JLabel("Sobrenome");
		lbSobrenome.setBounds(30, 122, 86, 14);
		contentPane.add(lbSobrenome);
		
		JButton btnBUSCAR = new JButton("Buscar ID:");
		btnBUSCAR.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				
				if(tfID.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Informe o ID!");
				} else {
				try {
					Connection con = Conexao.faz_conexao();
					
					String sql = "select *from dado_pessoa where id like ?";
					
					PreparedStatement st = con.prepareStatement(sql);
					
					st.setString(1, "%"+tfID.getText());
					
					ResultSet rs = st.executeQuery();
					
					while (rs.next()) {
						
						tfNome.setText(rs.getString("Nome"));
						
						tfSobrenome.setText(rs.getString("Sobrenome"));
						
					}
					
					rs.close();
					con.close();
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			
				
				
			}
			}
		});
		btnBUSCAR.setBounds(254, 53, 89, 23);
		contentPane.add(btnBUSCAR);
	}

}
